# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(coverage-guided-fuzz src/coverage-guided-fuzz.cpp)
set_property(TARGET coverage-guided-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-guided-fuzz lionss pthread)

add_executable(address-sanitizer src/address-sanitizer.cpp)
set_property(TARGET address-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(address-sanitizer lionss pthread)

add_executable(branch-prediction src/branch-prediction.cpp)
set_property(TARGET branch-prediction PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-prediction lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(aur-package src/aur-package.cpp)
set_property(TARGET aur-package PROPERTY CXX_STANDARD 11)
target_link_libraries(aur-package lionss pthread)

add_executable(gcc-libstdcxx src/gcc-libstdcxx.cpp)
set_property(TARGET gcc-libstdcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-libstdcxx lionss pthread)

add_executable(icx-build src/icx-build.cpp)
set_property(TARGET icx-build PROPERTY CXX_STANDARD 11)
target_link_libraries(icx-build lionss pthread)

add_executable(fuzz-minimize src/fuzz-minimize.cpp)
set_property(TARGET fuzz-minimize PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-minimize lionss pthread)

add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(nightly src/nightly.cpp)
set_property(TARGET nightly PROPERTY CXX_STANDARD 11)
target_link_libraries(nightly lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(valgrind-cachegrind src/valgrind-cachegrind.cpp)
set_property(TARGET valgrind-cachegrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-cachegrind lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(clang-trunk src/clang-trunk.cpp)
set_property(TARGET clang-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-trunk lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(gui-tests src/gui-tests.cpp)
set_property(TARGET gui-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(gui-tests lionss pthread)

add_executable(musl-build src/musl-build.cpp)
set_property(TARGET musl-build PROPERTY CXX_STANDARD 11)
target_link_libraries(musl-build lionss pthread)

add_executable(docstring-coverage src/docstring-coverage.cpp)
set_property(TARGET docstring-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(docstring-coverage lionss pthread)

add_executable(scaling-bench src/scaling-bench.cpp)
set_property(TARGET scaling-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(scaling-bench lionss pthread)

add_executable(uml-diagrams src/uml-diagrams.cpp)
set_property(TARGET uml-diagrams PROPERTY CXX_STANDARD 11)
target_link_libraries(uml-diagrams lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

add_executable(sandbox-build src/sandbox-build.cpp)
set_property(TARGET sandbox-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sandbox-build lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(debug-info-check src/debug-info-check.cpp)
set_property(TARGET debug-info-check PROPERTY CXX_STANDARD 11)
target_link_libraries(debug-info-check lionss pthread)

add_executable(asan-ubsan src/asan-ubsan.cpp)
set_property(TARGET asan-ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan-ubsan lionss pthread)

add_executable(lock-bench src/lock-bench.cpp)
set_property(TARGET lock-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(lock-bench lionss pthread)

add_executable(gcc-trunk src/gcc-trunk.cpp)
set_property(TARGET gcc-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-trunk lionss pthread)

add_executable(macos-universal src/macos-universal.cpp)
set_property(TARGET macos-universal PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-universal lionss pthread)

