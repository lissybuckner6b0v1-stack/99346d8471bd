// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("gcc libstdcxx"); }
int main(){
  announce();
  return lionss_run_workload("gcc-libstdcxx");
}
