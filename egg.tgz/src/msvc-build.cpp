// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("msvc build"); }
int main(){
  announce();
  return lionss_run_workload("msvc-build");
}
