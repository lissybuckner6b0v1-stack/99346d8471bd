// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("uml diagrams\n", stdout);
  return lionss_run_workload("uml-diagrams");
}
